#include <stdio.h>

int insere(int* v, int n){
  int i;
  int resta = 0;
  int y;
  for(i = 0 ;i < n ;i++){
    printf("Digite o valor do %d º número:\n",i);
    scanf("%d", &y);
    v[i] = y;
    resta = 10 -1 - i;
    printf("Faltam %d números\n", resta);
    printf("\n");

  }
  
  
}

void imprime(int*v, int n){
  int i;
  for(i=0;i<n;i++){
    printf("[%d]", v[i]);
  }
  printf("\n");
}

int busca(int* v, int x, int n){
 int i;
 for(i=0; i< n; i++){
   if(v[i] == x){
     printf("O seu número é [%d] e está na posição [%d]\n", x, i);
   
    }
  }
}

int deleta(int* v, int d, int n){
  int i;
  int j;
  for(i=0; i < n; i++){
    if(v[i] == d){
      for(j=i+1;j<n;j++){
        v[i] = v[j];
        i++;
      }
    }
    if(i == n-1){
      v[n-1]=0;
    }
    
  }
}
  

int main(void) {
  int v[10];
  insere(v, 10);
  imprime(v, 10);
  printf("\n");

  printf("Qual número você está buscando?\n");
  int x;
  scanf("%d", &x);
  busca(v, x, 10);
  printf("\n");

  printf("Qual número você deseja deletar?\n");
  int d;
  scanf("%d", &d);
  deleta(v, d, 10);
  imprime(v, 10);
  
  
  
  return 0;
}