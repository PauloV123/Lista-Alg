#include <stdio.h>
#include <string.h>
#include<stdlib.h>
#define MAX 100
#define MAX 100
struct Aluno{
  char registro[10];
  char nome[50];
  char email[30];
  char telefone[17];
  char p1[2];
  char p2[2];
  char p3[2]; 
};
static int k = 0;
/*struct Qtd{
  int n;
};*/

typedef struct Aluno A;
//typedef struct Qtd Q;
void Inserir(){
  A **a;
  //Q q;
 
  int temp = 0;
  int temp2;
  int quant = 0;
  a = malloc(sizeof(A*)*MAX);
  for(int i; i< MAX; i++){
    a = malloc(sizeof(A));
  }
  int j = 0;
  while(temp < MAX && temp2 == 0){

    printf("Insira o registro:\n");
    scanf("%s", a[j]->registro);
    printf("Insira o nome:\n");
    scanf("%s", a[j]->nome);
    printf("Insira o email:\n");
    scanf("%s", a[j]->email);
    printf("Insira o telefone:\n");
    scanf("%s", a[j]->telefone);
    printf("Insira a P1:\n");
    scanf("%s", a[j]->p1);
    printf("Insira a P2:\n");
    scanf("%s", a[j]->p2);
    printf("Insira a P3:\n");
    scanf("%s", a[j]->p3);

    printf("Deseja inserir mais alguem [0] SIM [1] NÃO:\n");
    scanf("%d", &temp2);

    temp++;
    j++;
    //q.n = quant++;
    k++;
  }
  
}

void Atualizar(){
   char op;
   char temp[50];
   A **a;
   
  do{
    printf("Digite a opcao que você deseja atualizar:\n");
    printf("\n");
    printf("1 - Registro\n");
    printf("2 - Nome\n");
    printf("3 - Email\n");
    printf("4 - Telefone\n");
    printf("5 - P1\n");
    printf("6 - P2\n");
    printf("7 - P3\n");
    scanf("%s", &op);
    switch(op){
      case '1':
        printf("Insira o registro:\n");
        scanf("%s", temp);
        for(int i=0;i<MAX;i++){
          if(strcmp(temp, a[i]->registro) == 0){
              a[i]->registro == temp; 
          }
        }
        
        break;
      case '2':
        printf("Insira o nome:\n");
        scanf("%s", temp);
        for(int i=0;i<MAX;i++){
          if(strcmp(temp, a[i]->nome) == 0){
              a[i]->nome == temp; 
            }
          }
        break;
      case '3':
        printf("Insira o email:\n");
        scanf("%s", temp);
        for(int i=0;i<MAX;i++){
          if(strcmp(temp, a[i]->email) == 0){
              a[i]->email == temp;
          }
        } 
        break;
      case '4':
        printf("Insira o telefone:\n");
        scanf("%s", temp);
        for(int i=0;i<MAX;i++){
          if(strcmp(temp, a[i]->telefone) == 0){
              a[i]->telefone == temp;
          }
        } 
        break;
      case '5':
        printf("Insira a P1:\n");
        scanf("%s", temp);
        for(int i=0;i<MAX;i++){
          if(strcmp(temp, a[i]->p1) == 0){
              a[i]->p1 == temp;
          }
        } 
        break;
      case '6':
        printf("Insira a P2:\n");
        scanf("%s", temp);
        for(int i=0;i<MAX;i++){
          if(strcmp(temp, a[i]->p2) == 0){
              a[i]->p2 == temp;
          }
        }
        break;
      case '7':
        printf("Insira a P3:\n");
        scanf("%s", temp);
        for(int i=0;i<MAX;i++){
          if(strcmp(temp, a[i]->p3) == 0){
              a[i]->p3 == temp;
          }
        }
        break;
      default:
        printf("\a Digite uma opção valida\n");
              
    }
  }while(op);
}

void Buscar(){
  char temp[50];
  A **a;

  printf("Insira o nome:\n");
        scanf("%s", temp);
        for(int i=0;i<MAX;i++){
          if(strcmp(temp, a[i]->nome) == 0){
              printf("Registro: %s\n", a[i]->registro);
              printf("Nome: %s\n", a[i]->nome);
              printf("Telefone: %s\n", a[i]->telefone);
              printf("Email: %s\n", a[i]->email);
              printf("P1: %s\n", a[i]->p1);
              printf("P2: %s\n", a[i]->p2);
              printf("P3: %s\n", a[i]->p3);
          }
        }
}
void Remover(){
  char temp[50];
  A **a;
  //Q q;
  printf("Insira o nome:\n");
        scanf("%s", temp);
        for(int i=0;i<MAX;i++){
          if(strcmp(temp, a[i]->nome) == 0){
              free(a[i]);
          }
        }
        //q.n = q.n - 1;
        k--;
}

void Media(){
  int m;
  char temp[50];
  A **a;
  int P1, P2, P3;

  printf("Insira o nome do aluno:\n");
        scanf("%s", temp);
        for(int i=0;i<MAX;i++){
          if(strcmp(temp, a[i]->nome) == 0){
              printf("Digite a nota de P1, P2 e P3 do aluno %s\n:", a[i]->nome);
              scanf("%d %d %d", &P1, &P2, &P3);
              m = (P1 + P2 + P3)/3;
              printf("Média: %d\n", m);
          }
        }
  
}

void Alterar(){
  char temp[50];
  A **a;
  int cont;

  printf("Insira o nome do aluno:\n");
        scanf("%s", temp);
        for(int i=0;i<MAX;i++){
          if(strcmp(temp, a[i]->nome) == 0){
              printf("1 - Registro\n");
              printf("2 - Email\n");
              printf("3 - Nome\n");
              printf("4 - Telefone\n");
              printf("5 - P1\n");
              printf("6 - P2\n");
              printf("7 - P3\n");
             scanf("%d", &cont);
             printf("Digite a alteração:\n");
             if(cont == 1){
                scanf("%s", a[i]->registro);
             }else if(cont == 2){
                scanf("%s", a[i]->email);
             }else if(cont == 3){
                scanf("%s", a[i]->nome);
             }else if(cont == 4){
               scanf("%s", a[i]->telefone);
             }else if(cont == 5){
               scanf("%s", a[i]->p1);
             }else if(cont == 6){
               scanf("%s", a[i]->p2);
             }else if(cont == 7){
               scanf("%s", a[i]->p3);
             }
          }
        }
}
void Quantidade(){
  //Q q;
  //printf("%d\n", q.n);
  printf("%d\n", k);
}

void menu(){
  printf("MENU!\n");
  char op;
  do{
    printf("Digite a opcao que voce deseja:\n");
    printf("\n");
    printf("1 - Inserir\n");
    printf("2 - Remover\n");
    printf("3 - Alterar\n");
    printf("4 - Buscar\n");
    printf("5 - Atualizar\n");
    printf("6 - Medias\n");
    printf("7 - Quantidade\n");
    printf("8 - Sair\n");
    scanf("%s", &op);
    switch(op){
      case '1':
        Inserir();
        break;
      case '2':
        Remover();
        break;
      case '3':
        Alterar();
        break;
      case '4':
        Buscar();
        break;
      case '5':
        Atualizar();
        break;
      case '6':
        Media();
        break;
      case '7':
        Quantidade();
        break;  
      case '8':
        printf("VOCÊ SAIU DO PROGRAMA\n");
        break;
      default:
        printf("\a Digite uma opção valida\n");
              
    }
  }
  while(op);
}



int main(void) {
  menu();
  return 0;
}