#include <stdio.h>
#include<stdlib.h>

struct vetor{
  int valor;
  
};


typedef struct vetor V;

int main(void) {
  V **v;
  int n = 5;

  v= malloc(sizeof(V*)*5);
  int i;
  
  //cria vetor dinamico
  for(i=0;i<n;i++){
    v[i] = malloc(sizeof(V));
  }
  //insere
  for(i=0;i<n;i++){
    v[i]->valor = i+4;
  }
  //imprime
  printf("Seu vetor é:\n");
  for(i=0;i<n;i++){
    printf("[%d] ", v[i]->valor);
  }
  printf("\n");

  //busca
  printf("Digite o número da busca:\n");
  int x;
  scanf("%d",&x);
  for(i=0;i<n;i++){
    if(v[i]->valor == x){
      printf("Seu número é %d e está na posição %d\n", x, i);
    }
  }
  printf("\n");

  //deleta
  printf("Digite o número para ser deletado:\n");
  int y;
  int j;
  scanf("%d",&y);
  for(i=0; i < n; i++){
    if(v[i]->valor == y){
      for(j=i+1;j<n;j++){
        v[i]->valor = v[j]->valor;
        i++;
      }
    }
    if(i == n-1){
      v[n-1]->valor = 0;
    }
    
  }
  
  for(i=0;i<n;i++){
    printf("[%d] ", v[i]->valor);
  }
  
  

  printf("\n");
  printf("\n"); 

  //Trocar tamanho
  //vou criar mais 2 vetores dinamicos e trocar o tamanho deles
  V** v2;
  V** v3;
  int tamanho1, tamanho2;
  printf("Digite o tamanho dos vetores:\n");
  scanf("%d", &tamanho1);
  scanf("%d", &tamanho2);
  v2 = malloc(sizeof(V*)*tamanho1);

   for(i=0;i<tamanho1;i++){
    v2[i] = malloc(sizeof(V));
  }

  v3 = malloc(sizeof(V*)*tamanho2);

   for(i=0;i<tamanho2;i++){
    v3[i] = malloc(sizeof(V));
  }

  for(i=0;i<tamanho1;i++){
    v2[i]->valor = i;
  }
  printf("\n");
  printf("Primeiro vetor:\n");

  for(i=0;i<tamanho1;i++){
    printf("[%d]", v2[i]->valor);
  }
  printf("\n");
  
  for(i=0;i<tamanho2;i++){
    v3[i]->valor = 10 + i;
  }
  printf("Segundo vetor:\n");
  for(i=0;i<tamanho2;i++){
    printf("[%d]", v3[i]->valor);
  }
  printf("\n");
  printf("\n"); 

  
  //-----------------------------------
  V** temp;
  V** temp2;
  if(tamanho2>tamanho1){
    temp = malloc(sizeof(V*)*tamanho2);
    for(i=0;i<tamanho2;i++){
      temp[i] = malloc(sizeof(V));
  }
    for(i=0;i<tamanho1;i++){
      temp[i]->valor = i;
  }
    for(i=0;i<tamanho1;i++){
      v2[i]->valor = v3[i]->valor;
  }
    printf("Primeiro vetor:\n");
  
    for(i=0;i<tamanho1;i++){
      printf("[%d]", v2[i]->valor);
  }
    printf("\n");
    for(i=0;i<tamanho2;i++){
      v3[i]->valor = temp[i]->valor;
  }
    printf("Segundo vetor:\n");
    for(i=0;i<tamanho2;i++){
      printf("[%d]", v3[i]->valor);
    }
  }

  if(tamanho2<tamanho1){
    temp2 = malloc(sizeof(V*)*tamanho2);
  for(i=0;i<tamanho2;i++){
    temp2[i] = malloc(sizeof(V));
  }
  for(i=0;i<tamanho2;i++){
    temp2[i]->valor = i;
  }
  for(i=0;i<tamanho2;i++){
    v2[i]->valor = v3[i]->valor;
  }
  printf("Primeiro vetor:\n");
  
  for(i=0;i<tamanho1;i++){
    printf("[%d]", v2[i]->valor);
  }
  printf("\n");
  for(i=0;i<tamanho2;i++){
    v3[i]->valor = temp2[i]->valor;
  }
  printf("Segundo vetor:\n");
  for(i=0;i<tamanho2;i++){
    printf("[%d]", v3[i]->valor);
  }
  }
  



  printf("\n");
  printf("\n");

  //inverter valores
  printf("Primeiro vetor:\n");
  for(i=0;i<n;i++){
    printf("[%d] ", v[i]->valor);
  }
  printf("\n");
  printf("Invertendo valores\n");
  for(i=n-1;i>-1;i--){
    printf("[%d] ", v[i]->valor);
  }

printf("\n");
printf("\n");

//outro tamanho de vetor
V **v4;
printf("Digite o tamanho do vetor:");
int tamanho3;
scanf("%d", &tamanho3);
v4= malloc(sizeof(V*)*tamanho3);
  
  for(i=0;i<tamanho3;i++){
    v4[i] = malloc(sizeof(V));
  }
  int cont;
  if(tamanho3 > n){
    for(i=0;i<n;i++){
      v4[i]->valor = i+4;
  
    }
  }else{
    for(i=0;i<tamanho3;i++){
      v4[i]->valor = i+4;
  
    }
  }
  

  printf("Seu vetor é:\n");
  for(i=0;i<tamanho3;i++){
    printf("[%d] ", v4[i]->valor);
    }
  
  
  
  printf("\n");





//free nos vetores
  for(i=0;i<tamanho1;i++){
    free(v2[i]);
    free(temp[i]);
    
  }
  for(i=0;i<tamanho2;i++){
    free(v3[i]);
    free(temp2[i]);
  }

  for(i=0;i<n;i++){
    free(v[i]);
  }
  for(i=0;i<tamanho3;i++){
    free(v4[i]);
  }
  
  return 0;
}